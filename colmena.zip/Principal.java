import java.util.Scanner;
import java.lang.Math.*;

public class Principal {
    
    public static void golpe(Reina c) {
        int n = c.getAbejas();

        if (n > 0)  {
            System.out.println("\nSe ha muerto la abeja reina, una trabajadora asciende a reina");
            c.setAbejas(n-1); //nuevo total = antiguo - 1
            System.out.println("abejas antes del golpe: " + n + "; abejas despues del golpe: " + c.getAbejas());
        } else {
            System.out.println("\nLa colmena se quedo sin esclavos");
            esclavos(c, 0);
        }
    }

    public static void esclavos(Reina c, int valor) {
        int nuevosEsclavos;

        if (valor == 0) {
            System.out.println("La Reina genera esclavos");

            nuevosEsclavos = (int)(Math.random()*100+1); //genera numero de 1 a 100
            c.setAbejas(nuevosEsclavos); //nuevo total = nuevos

            System.out.println("Colmena con " + c.getAbejas() + " esclavos");
        }

        if (valor == 1) {
            int n = c.getAbejas();
            System.out.println("\nNumero actual de abejas: " + n);

            nuevosEsclavos = (int)(Math.random()*100+1); //genera numero de 1 a 100

            n += nuevosEsclavos;
            c.setAbejas(n); //nuevo total = antiguo + nuevos
            
            System.out.println("Cantidad nueva: " + nuevosEsclavos + "; nueva cantidad: " + c.getAbejas());
        }

    }

    public static void main(String[] args) {
        int abejas, opcion;
        Reina c;

        Scanner teclado = new Scanner(System.in);

        System.out.print("Numero de abejas: ");
        abejas = teclado.nextInt();

        while (abejas < 0) {
            System.out.println("Tiene que ser mayor o igual a cero!");
            System.out.print("Numero de abejas: ");
            abejas = teclado.nextInt();
        }
        
        if (abejas == 0) {
            //se crea la reina y sus esclavos
            System.out.println("\nSe genera una Reina");
            c = Reina.getReina(abejas);
            esclavos(c, 0);
        } else {
            //se crea la reina con los esclavos del input
            c = Reina.getReina(abejas);
        }

        do {
            System.out.println("\nMenu:\n\t1) Reina esclaviza nuevos trabajadores\n\t2) golpe de estado\n\t3) Salir");
            System.out.print("Ingrese opcion: ");
            opcion = teclado.nextInt();
            switch (opcion) {
                case 1:
                    //Reina esclaviza nuevos trabajadores
                    esclavos(c, 1);
                    break;

                case 2:
                    //golpe de estado
                    golpe(c);
                    break;
            }
        } while (opcion != 3);
    }
}