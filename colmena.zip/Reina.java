public class Reina {
    private int abejas;
    private static Reina micolmena;
    
    public static Reina getReina(int abejas) {
        if (micolmena == null) {
            micolmena = new Reina(abejas);
        }
        return micolmena;
    }
    
    private Reina(int abejas){
        this.abejas = abejas;
    }

    public int getAbejas() {
        return abejas;
    }

    public void setAbejas(int abejas) {
        this.abejas = abejas;
    }
}